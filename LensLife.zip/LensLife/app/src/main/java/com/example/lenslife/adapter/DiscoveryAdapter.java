package com.example.lenslife.adapter;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.example.lenslife.R;
import com.example.lenslife.model.DiscoveryPhotoModel;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class DiscoveryAdapter extends RecyclerView.Adapter<DiscoveryAdapter.PhotoViewHolder> {

    private Context context;
    private List<DiscoveryPhotoModel> photoList;
    private OnFollowClickListener followClickListener;

    public DiscoveryAdapter(Context context, List<DiscoveryPhotoModel> photoList, OnFollowClickListener followClickListener) {
        this.context = context;
        this.photoList = photoList;
        this.followClickListener = followClickListener;
    }

    @NonNull
    @Override
    public PhotoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_discovery, parent, false);
        return new PhotoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PhotoViewHolder holder, int position) {
        DiscoveryPhotoModel photo = photoList.get(position);

        if (isContextValid()) {
            Glide.with(context)
                    .load(photo.getImageUrl())
                    .transform(new CenterCrop(), new RoundedCorners(16))
                    .into(holder.photoImageView);

            if (photo.getUserProfilePicUrl() != null) {
                Glide.with(context)
                        .load(photo.getUserProfilePicUrl())
                        .into(holder.profileImageView);
            } else {
                holder.profileImageView.setImageResource(R.drawable.ic_profile);
            }
        }

        holder.userNameTextView.setText(photo.getUserName() != null ? photo.getUserName() : "Loading...");

        holder.followButton.setText(photo.isFollowing() ? "Following" : "Follow");
        holder.followButton.setBackgroundColor(photo.isFollowing() ? Color.GRAY : Color.BLUE);

        holder.followButton.setOnClickListener(v -> {
            boolean isCurrentlyFollowing = photo.isFollowing();
            followClickListener.onFollowClick(photo.getUserId(), position, !isCurrentlyFollowing);
            animateFollowButton(holder.followButton, !isCurrentlyFollowing);
        });
    }

    private boolean isContextValid() {
        return context != null && !(context instanceof Activity) || !((Activity) context).isDestroyed();
    }


    @Override
    public int getItemCount() {
        return photoList.size();
    }

    public class PhotoViewHolder extends RecyclerView.ViewHolder {
        ImageView photoImageView;
        CircleImageView profileImageView;
        TextView userNameTextView;
        Button followButton;

        public PhotoViewHolder(@NonNull View itemView) {
            super(itemView);
            photoImageView = itemView.findViewById(R.id.photoImageView);
            profileImageView = itemView.findViewById(R.id.profileImageView);
            userNameTextView = itemView.findViewById(R.id.userNameTextView);
            followButton = itemView.findViewById(R.id.followButton);
        }
    }

    private void animateFollowButton(Button button, boolean isFollowing) {
        String startText = isFollowing ? "Follow" : "Following";
        String endText = isFollowing ? "Following" : "Follow";
        int startColor = isFollowing ? Color.BLUE : Color.GRAY;
        int endColor = isFollowing ? Color.GRAY : Color.BLUE;

        ValueAnimator colorAnimator = ValueAnimator.ofArgb(startColor, endColor);
        colorAnimator.addUpdateListener(animation -> button.setBackgroundColor((int) animation.getAnimatedValue()));
        colorAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        colorAnimator.setDuration(300);

        ObjectAnimator textAnimator = ObjectAnimator.ofFloat(button, "alpha", 1f, 0f);
        textAnimator.setDuration(150);
        textAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        textAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                button.setText(endText);
                ObjectAnimator textFadeInAnimator = ObjectAnimator.ofFloat(button, "alpha", 0f, 1f);
                textFadeInAnimator.setDuration(150);
                textFadeInAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
                textFadeInAnimator.start();
            }
        });

        textAnimator.start();
        colorAnimator.start();
    }

    public interface OnFollowClickListener {
        void onFollowClick(String userId, int position, boolean follow);
    }
}
