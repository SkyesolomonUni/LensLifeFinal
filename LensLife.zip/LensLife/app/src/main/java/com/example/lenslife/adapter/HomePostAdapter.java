package com.example.lenslife.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.lenslife.R;
import com.example.lenslife.model.HomePostModel;
import com.example.lenslife.model.LikedPost;
import com.example.lenslife.model.SavedPost;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomePostAdapter extends RecyclerView.Adapter<HomePostAdapter.PostViewHolder> {

    private Context context;
    private List<HomePostModel> posts;
    private String currentUserId;
    private FirebaseFirestore db;

    public HomePostAdapter(Context context, List<HomePostModel> posts, String currentUserId) {
        this.context = context;
        this.posts = posts;
        this.currentUserId = currentUserId;
        this.db = FirebaseFirestore.getInstance();
    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_home, parent, false);
        return new PostViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        HomePostModel post = posts.get(position);

        fetchUserInfo(post.getUserId(), holder);

        if (isContextValid()) {
            Glide.with(context).load(post.getImageUrl()).into(holder.postImage);
        }

        updateLikeButton(holder.likeButton, post.isLikedByCurrentUser());
        checkSaveStatus(post.getPostId(), holder.saveButton);

        holder.likeButton.setOnClickListener(v -> toggleLike(post, holder.likeButton));
        holder.saveButton.setOnClickListener(v -> toggleSave(post, holder.saveButton));
        holder.menuButton.setOnClickListener(v -> showPopupMenu(v, post));

        holder.likesCount.setText(String.format("%d likes", post.getLikesCount()));
    }

    private boolean isContextValid() {
        return context != null && !(context instanceof Activity) || !((Activity) context).isDestroyed();
    }

    private void fetchUserInfo(String userId, PostViewHolder holder) {
        db.collection("users").document(userId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists() && isContextValid()) {
                        String userName = documentSnapshot.getString("name");
                        String profilePicUrl = documentSnapshot.getString("profilePicUrl");
                        holder.userName.setText(userName);
                        Glide.with(context).load(profilePicUrl).into(holder.profileImage);
                    }
                })
                .addOnFailureListener(e -> {
                    if (isContextValid()) {
                        Toast.makeText(context, "Error fetching user info", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    @Override
    public int getItemCount() {
        return posts.size();
    }

    private void updateLikeButton(ImageView likeButton, boolean isLiked) {
        likeButton.setImageResource(isLiked ? R.drawable.ic_like_filled : R.drawable.ic_like);
    }

    private void updateSaveButton(ImageView saveButton, boolean isSaved) {
        saveButton.setImageResource(isSaved ? R.drawable.ic_save_filled : R.drawable.ic_save);
    }

    private void toggleLike(HomePostModel post, ImageView likeButton) {
        boolean currentLikeStatus = post.isLikedByCurrentUser();
        post.setLikedByCurrentUser(!currentLikeStatus);
        updateLikeButton(likeButton, !currentLikeStatus);

        if (!currentLikeStatus) {
            // Like
            LikedPost likedPost = new LikedPost(post.getPostId(), currentUserId, Timestamp.now());
            db.collection("posts").document(post.getPostId()).collection("likes").document(currentUserId).set(likedPost);
            updateLikesCount(post, 1);
        } else {
            // Unlike
            db.collection("posts").document(post.getPostId()).collection("likes").document(currentUserId).delete();
            updateLikesCount(post, -1);
        }
    }

    private void updateLikesCount(HomePostModel post, int increment) {
        post.setLikesCount(post.getLikesCount() + increment);
        notifyItemChanged(posts.indexOf(post));

        db.collection("posts").document(post.getPostId())
                .update("likesCount", FieldValue.increment(increment));
    }

    private void checkSaveStatus(String postId, ImageView saveButton) {
        db.collection("users").document(currentUserId).collection("savedPosts").document(postId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    boolean isSaved = documentSnapshot.exists();
                    updateSaveButton(saveButton, isSaved);
                });
    }

    private void toggleSave(HomePostModel post, ImageView saveButton) {
        db.collection("users").document(currentUserId).collection("savedPosts").document(post.getPostId()).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        // Unsave
                        documentSnapshot.getReference().delete();
                        updateSaveButton(saveButton, false);
                    } else {
                        // Save
                        SavedPost savedPost = new SavedPost(post.getPostId(), post.getUserId(), currentUserId, post.getImageUrl(), Timestamp.now());
                        db.collection("users").document(currentUserId).collection("savedPosts").document(post.getPostId()).set(savedPost);
                        updateSaveButton(saveButton, true);
                    }
                });
    }

    private void showPopupMenu(View view, HomePostModel post) {
        PopupMenu popupMenu = new PopupMenu(context, view);
        popupMenu.inflate(R.menu.post_menu);
        popupMenu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.action_unfollow) {
                unfollowUser(post.getUserId());
                return true;
            } else if (itemId == R.id.action_block) {
                blockUser(post.getUserId());
                return true;
            } else {
                return false;
            }
        });
        popupMenu.show();
    }

    private void unfollowUser(String userId) {
        db.collection("users").document(currentUserId)
                .update("following", FieldValue.arrayRemove(userId))
                .addOnSuccessListener(aVoid -> {
                    posts.removeIf(post -> post.getUserId().equals(userId));
                    notifyDataSetChanged();
                });
    }

    private void blockUser(String userId) {
        db.collection("users").document(currentUserId)
                .update("blocked", FieldValue.arrayUnion(userId))
                .addOnSuccessListener(aVoid -> {
                    posts.removeIf(post -> post.getUserId().equals(userId));
                    notifyDataSetChanged();
                });
    }

    static class PostViewHolder extends RecyclerView.ViewHolder {
        CircleImageView profileImage;
        TextView userName;
        ImageView postImage;
        TextView caption;
        ImageView likeButton;
        ImageView saveButton;
        ImageView menuButton;
        TextView likesCount;

        PostViewHolder(@NonNull View itemView) {
            super(itemView);
            profileImage = itemView.findViewById(R.id.profileImage);
            userName = itemView.findViewById(R.id.userName);
            postImage = itemView.findViewById(R.id.postImage);
            likeButton = itemView.findViewById(R.id.likeButton);
            saveButton = itemView.findViewById(R.id.saveButton);
            menuButton = itemView.findViewById(R.id.menuButton);
            likesCount = itemView.findViewById(R.id.likesCount);
        }
    }
}