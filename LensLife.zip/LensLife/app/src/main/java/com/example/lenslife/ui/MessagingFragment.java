package com.example.lenslife.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lenslife.R;
import com.example.lenslife.adapter.ChatAdapter;
import com.example.lenslife.adapter.ChatUserListAdapter;
import com.example.lenslife.model.Message;
import com.example.lenslife.model.User;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldPath;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MessagingFragment extends Fragment {
    private RecyclerView userListRecyclerView;
    private RecyclerView chatRecyclerView;
    private EditText messageEditText;
    private ImageButton sendButton;
    private ImageButton recordButton;
    private TextView emptyStateText;
    private View chatContainer;

    private ChatUserListAdapter userListAdapter;
    private ChatAdapter chatAdapter;

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String currentUserId;
    private String selectedUserId;
    private View messageInputLayout;
    private View recordingControlsLayout;
    private ImageButton pauseResumeButton;
    private TextView recordingTimeText;
    private ImageButton deleteRecordingButton;
    private ImageButton sendRecordingButton;

    private MediaRecorder mediaRecorder;
    private String audioFilePath;
    private boolean isRecording = false;
    private boolean isPaused = false;
    private long startTime = 0L;
    private long timeInMilliseconds = 0L;
    private long timeSwapBuff = 0L;
    private long updatedTime = 0L;
    private Handler timerHandler = new Handler();
    private static final String LOG_TAG = "AudioRecording";
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private String[] permissions = {Manifest.permission.RECORD_AUDIO};
    private boolean permissionToRecordAccepted = false;
    private View loadingView;
    private MediaRecorder recorder;
    private String fileName = null;
    private Handler handler = new Handler();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_messaging, container, false);

        userListRecyclerView = view.findViewById(R.id.userListRecyclerView);
        chatRecyclerView = view.findViewById(R.id.chatRecyclerView);
        messageEditText = view.findViewById(R.id.messageEditText);
        sendButton = view.findViewById(R.id.sendButton);
        recordButton = view.findViewById(R.id.recordButton);
        emptyStateText = view.findViewById(R.id.emptyStateText);
        chatContainer = view.findViewById(R.id.chatContainer);
        messageInputLayout = view.findViewById(R.id.messageInputLayout);
        loadingView = view.findViewById(R.id.loadingView);

        recordingControlsLayout = view.findViewById(R.id.recordingControlsLayout);
        pauseResumeButton = view.findViewById(R.id.pauseResumeButton);
        recordingTimeText = view.findViewById(R.id.recordingTimeText);
        deleteRecordingButton = view.findViewById(R.id.deleteRecordingButton);
        sendRecordingButton = view.findViewById(R.id.sendRecordingButton);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        currentUserId = mAuth.getCurrentUser().getUid();

        setupUserList();
        setupChat();
        setupListeners();

        return view;
    }
    private void setupListeners() {
        sendButton.setOnClickListener(v -> sendMessage());
        recordButton.setOnClickListener(v -> {
            if (isRecording) {
                stopRecording();
            } else {
                checkAudioPermission();
            }
        });
        pauseResumeButton.setOnClickListener(v -> onPauseResume());
        deleteRecordingButton.setOnClickListener(v -> onDeleteRecording());
        sendRecordingButton.setOnClickListener(v -> onSendRecording());
    }
    private void setupUserList() {
        userListAdapter = new ChatUserListAdapter(new ArrayList<>(), this::onUserSelected);
        userListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        userListRecyclerView.setAdapter(userListAdapter);
        loadUsers();
    }

    private void setupChat() {
        chatAdapter = new ChatAdapter(new ArrayList<>(), currentUserId);
        chatRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        chatRecyclerView.setAdapter(chatAdapter);
    }

    private void loadUsers() {
        db.collection("users").document(currentUserId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    List<String> following = (List<String>) documentSnapshot.get("following");
                    if (following != null && !following.isEmpty()) {
                        fetchUserDetails(following);
                    }
                });
    }

    private void fetchUserDetails(List<String> userIds) {
        db.collection("users").whereIn(FieldPath.documentId(), userIds).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<User> users = new ArrayList<>();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        User user = document.toObject(User.class);
                        user.setUserId(document.getId());
                        users.add(user);
                    }
                    userListAdapter.updateUsers(users);
                });
    }

    private void onUserSelected(User user) {
        selectedUserId = user.getUserId();
        emptyStateText.setVisibility(View.GONE);
        chatRecyclerView.setVisibility(View.VISIBLE);
        messageInputLayout.setVisibility(View.VISIBLE);
        loadMessages();
    }

    private void loadMessages() {
        String chatId = getChatId(currentUserId, selectedUserId);
        db.collection("chats").document(chatId).collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e("MessagingFragment", "Listen failed.", error);
                        return;
                    }

                    List<Message> messages = new ArrayList<>();
                    for (QueryDocumentSnapshot doc : value) {
                        messages.add(doc.toObject(Message.class));
                    }
                    chatAdapter.updateMessages(messages);
                    chatRecyclerView.scrollToPosition(messages.size() - 1);
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            permissionToRecordAccepted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (permissionToRecordAccepted) {
                startRecording();
            } else {
                Toast.makeText(getContext(), "Permission to record audio denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void checkAudioPermission() {
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO_PERMISSION);
        } else {
            startRecording();
        }
    }

    private void startRecording() {
        recorder = new MediaRecorder();
        fileName = getActivity().getExternalCacheDir().getAbsolutePath();
        fileName += "/audiorecord.3gp";

        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recorder.setOutputFile(fileName);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            recorder.prepare();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }

        recorder.start();
        isRecording = true;
        recordButton.setImageResource(R.drawable.ic_pause);

        // Hide message input layout and show recording controls
        messageInputLayout.setVisibility(View.GONE);
        recordingControlsLayout.setVisibility(View.VISIBLE);

        startTime = SystemClock.uptimeMillis();
        handler.postDelayed(updateTimerThread, 0);
    }

    private void stopRecording() {
        if (recorder != null) {
            try {
                recorder.stop();
                recorder.release();
            } catch (IllegalStateException e) {
                Log.e(LOG_TAG, "Error stopping recorder: " + e.getMessage());
            }
            recorder = null;
        }
        isRecording = false;
        recordButton.setImageResource(R.drawable.ic_mic);
        handler.removeCallbacks(updateTimerThread);

        // Show message input layout and hide recording controls
        messageInputLayout.setVisibility(View.VISIBLE);
        recordingControlsLayout.setVisibility(View.GONE);
    }

    private void onPauseResume() {
        if (isPaused) {
            recorder.resume();
            pauseResumeButton.setImageResource(R.drawable.ic_pause);
            startTime = SystemClock.uptimeMillis();
            handler.postDelayed(updateTimerThread, 0);
        } else {
            recorder.pause();
            pauseResumeButton.setImageResource(R.drawable.ic_play);
            timeSwapBuff += timeInMilliseconds;
            handler.removeCallbacks(updateTimerThread);
        }
        isPaused = !isPaused;
    }

    private void onDeleteRecording() {
        stopRecording();
        File file = new File(fileName);
        file.delete();
        messageInputLayout.setVisibility(View.VISIBLE);
        recordingControlsLayout.setVisibility(View.GONE);
        recordingTimeText.setText("00:00");
        timeSwapBuff = 0L;
        timeInMilliseconds = 0L;
    }

    private void onSendRecording() {
        stopRecording();
        loadingView.setVisibility(View.VISIBLE);
        uploadAudioToFirebaseStorage();
    }

    private void uploadAudioToFirebaseStorage() {
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();
        Uri file = Uri.fromFile(new File(fileName));
        StorageReference audioRef = storageRef.child("audio/" + file.getLastPathSegment());

        audioRef.putFile(file)
                .addOnSuccessListener(taskSnapshot -> {
                    audioRef.getDownloadUrl().addOnSuccessListener(uri -> {
                        String audioUrl = uri.toString();
                        sendAudioMessage(audioUrl);
                    });
                })
                .addOnFailureListener(e -> {
                    loadingView.setVisibility(View.GONE);
                    Toast.makeText(getContext(), "Failed to upload audio", Toast.LENGTH_SHORT).show();
                });
    }

    private void sendAudioMessage(String audioUrl) {
        String chatId = getChatId(currentUserId, selectedUserId);
        Message message = new Message(currentUserId, selectedUserId, "", Timestamp.now());
        message.setAudioUrl(audioUrl);

        db.collection("chats").document(chatId).collection("messages")
                .add(message)
                .addOnSuccessListener(documentReference -> {
                    loadingView.setVisibility(View.GONE);
                    messageInputLayout.setVisibility(View.VISIBLE);
                    recordingControlsLayout.setVisibility(View.GONE);
                    recordingTimeText.setText("00:00");
                    timeSwapBuff = 0L;
                    timeInMilliseconds = 0L;
                })
                .addOnFailureListener(e -> {
                    loadingView.setVisibility(View.GONE);
                    Toast.makeText(getContext(), "Failed to send audio message", Toast.LENGTH_SHORT).show();
                });
    }

    private Runnable updateTimerThread = new Runnable() {
        public void run() {
            timeInMilliseconds = SystemClock.uptimeMillis() - startTime;
            updatedTime = timeSwapBuff + timeInMilliseconds;
            int secs = (int) (updatedTime / 1000);
            int mins = secs / 60;
            secs = secs % 60;
            recordingTimeText.setText(String.format("%02d:%02d", mins, secs));
            handler.postDelayed(this, 0);
        }
    };

    private void sendMessage() {
        String messageText = messageEditText.getText().toString().trim();
        if (!messageText.isEmpty()) {
            String chatId = getChatId(currentUserId, selectedUserId);
            Message message = new Message(currentUserId, selectedUserId, messageText, Timestamp.now());

            db.collection("chats").document(chatId).collection("messages")
                    .add(message)
                    .addOnSuccessListener(documentReference -> {
                        messageEditText.setText("");
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(getContext(), "Failed to send message", Toast.LENGTH_SHORT).show();
                    });
        }
    }
    private String getChatId(String userId1, String userId2) {
        return userId1.compareTo(userId2) < 0 ? userId1 + "_" + userId2 : userId2 + "_" + userId1;
    }
}