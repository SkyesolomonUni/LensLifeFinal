package com.example.lenslife.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.lenslife.R;
import com.example.lenslife.model.User;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatUserListAdapter extends RecyclerView.Adapter<ChatUserListAdapter.UserViewHolder> {
    private List<User> users;
    private OnUserClickListener listener;

    public ChatUserListAdapter(List<User> users, OnUserClickListener listener) {
        this.users = users;
        this.listener = listener;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_user_list, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User user = users.get(position);
        holder.bind(user);
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public void updateUsers(List<User> newUsers) {
        users.clear();
        users.addAll(newUsers);
        notifyDataSetChanged();
    }

    class UserViewHolder extends RecyclerView.ViewHolder {
        private CircleImageView profileImage;

        UserViewHolder(@NonNull View itemView) {
            super(itemView);
            profileImage = itemView.findViewById(R.id.profileImage);
        }

        void bind(User user) {
            Glide.with(itemView.getContext())
                    .load(user.getProfilePicUrl())
                    .placeholder(R.drawable.ic_profile)
                    .into(profileImage);

            itemView.setOnClickListener(v -> listener.onUserClick(user));
        }
    }

    public interface OnUserClickListener {
        void onUserClick(User user);
    }

}
