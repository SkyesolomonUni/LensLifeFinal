package com.example.lenslife.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.lenslife.LoginActivity;
import com.example.lenslife.R;
import com.example.lenslife.adapter.ProfilePostsAdapter;
import com.example.lenslife.model.AddPost;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileFragment extends Fragment {

    private CircleImageView profileImageView;
    private TextView nameTextView;
    private RecyclerView postsRecyclerView;
    private ProfilePostsAdapter profilePostsAdapter;
    private List<AddPost> posts;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private String userId;
    private DrawerLayout drawerLayout;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        drawerLayout = view.findViewById(R.id.drawerLayout);
        ImageView settingsButton = view.findViewById(R.id.settingsButton);

        settingsButton.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.END));

        setupSidebarButtons(view);
        profileImageView = view.findViewById(R.id.profile_image);
        nameTextView = view.findViewById(R.id.profile_name);
        postsRecyclerView = view.findViewById(R.id.posts_recycler_view);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        userId = mAuth.getCurrentUser().getUid();

        posts = new ArrayList<>();
        profilePostsAdapter = new ProfilePostsAdapter(getContext(), posts);
        postsRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        postsRecyclerView.setAdapter(profilePostsAdapter);

        loadUserProfile();
        loadUserPosts();

        return view;
    }
    private void setupSidebarButtons(View view) {
        Button savedPostsButton = drawerLayout.findViewById(R.id.savedPostsButton);
        Button logoutButton = drawerLayout.findViewById(R.id.logoutButton);

        if (savedPostsButton == null || logoutButton == null) {
            // Log an error or show a toast message
            return;
        }

        savedPostsButton.setOnClickListener(v -> {
            // Navigate to SavedPostsFragment
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new SavedPostsFragment())
                    .addToBackStack(null)
                    .commit();
            drawerLayout.closeDrawer(GravityCompat.END);
        });

        logoutButton.setOnClickListener(v -> {
            // Perform logout
            FirebaseAuth.getInstance().signOut();
            // Navigate to LoginActivity
            startActivity(new Intent(getActivity(), LoginActivity.class));
            getActivity().finish();
        });
    }
    private void loadUserProfile() {
        db.collection("users").document(userId).get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        String name = document.getString("name");
                        nameTextView.setText(name);
                    }
                });

        StorageReference profilePicRef = storage.getReference().child("profile_pics/" + userId + ".jpg");
        profilePicRef.getDownloadUrl().addOnSuccessListener(uri -> {
            if (isAdded()) {
                Glide.with(requireContext())
                        .load(uri)
                        .placeholder(R.drawable.ic_profile)
                        .error(R.drawable.ic_profile)
                        .into(profileImageView);
            }
        }).addOnFailureListener(e -> {
            // Load default image if profile picture is not available
            profileImageView.setImageResource(R.drawable.ic_profile);
        });
    }

    private void loadUserPosts() {
        db.collection("posts").whereEqualTo("userId", userId).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    posts.clear();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        AddPost post = document.toObject(AddPost.class);
                        // Ensure likesCount is properly set
                        if (document.contains("likesCount")) {
                            post.setLikesCount(document.getLong("likesCount").intValue());
                        } else {
                            post.setLikesCount(0);
                        }
                        posts.add(post);
                    }
                    profilePostsAdapter.notifyDataSetChanged();
                });
    }
}
