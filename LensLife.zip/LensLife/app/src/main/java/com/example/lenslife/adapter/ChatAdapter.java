package com.example.lenslife.adapter;


import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lenslife.R;
import com.example.lenslife.model.Message;
import com.google.firebase.Timestamp;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int VIEW_TYPE_MESSAGE_SENT = 1;
    private static final int VIEW_TYPE_MESSAGE_RECEIVED = 2;
    private static final int VIEW_TYPE_AUDIO_SENT = 3;
    private static final int VIEW_TYPE_AUDIO_RECEIVED = 4;

    private List<Message> messages;
    private String currentUserId;

    private MediaPlayer currentMediaPlayer;
    private ImageButton currentPlayButton;

    public ChatAdapter(List<Message> messages, String currentUserId) {
        this.messages = messages;
        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;

        switch (viewType) {
            case VIEW_TYPE_MESSAGE_SENT:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_sent, parent, false);
                return new SentMessageHolder(view);
            case VIEW_TYPE_MESSAGE_RECEIVED:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_received, parent, false);
                return new ReceivedMessageHolder(view);
            case VIEW_TYPE_AUDIO_SENT:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_audio_sent, parent, false);
                return new SentAudioHolder(view);
            case VIEW_TYPE_AUDIO_RECEIVED:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_audio_received, parent, false);
                return new ReceivedAudioHolder(view);
            default:
                throw new IllegalArgumentException("Invalid view type");
        }
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message message = messages.get(position);

        switch (holder.getItemViewType()) {
            case VIEW_TYPE_MESSAGE_SENT:
                ((SentMessageHolder) holder).bind(message);
                break;
            case VIEW_TYPE_MESSAGE_RECEIVED:
                ((ReceivedMessageHolder) holder).bind(message);
                break;
            case VIEW_TYPE_AUDIO_SENT:
                ((SentAudioHolder) holder).bind(message);
                break;
            case VIEW_TYPE_AUDIO_RECEIVED:
                ((ReceivedAudioHolder) holder).bind(message);
                break;
        }
    }

    @Override
    public int getItemViewType(int position) {
        Message message = messages.get(position);
        if (message.getSenderId().equals(currentUserId)) {
            return message.getAudioUrl() != null ? VIEW_TYPE_AUDIO_SENT : VIEW_TYPE_MESSAGE_SENT;
        } else {
            return message.getAudioUrl() != null ? VIEW_TYPE_AUDIO_RECEIVED : VIEW_TYPE_MESSAGE_RECEIVED;
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }


    public void updateMessages(List<Message> newMessages) {
        messages.clear();
        messages.addAll(newMessages);
        notifyDataSetChanged();
    }

    class SentMessageHolder extends RecyclerView.ViewHolder {
        TextView messageText, timeText;

        SentMessageHolder(View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.text_message_body);
            timeText = itemView.findViewById(R.id.text_message_time);
        }

        void bind(Message message) {
            messageText.setText(message.getContent());
            timeText.setText(formatDateTime(message.getTimestamp()));
        }
    }

    class ReceivedMessageHolder extends RecyclerView.ViewHolder {
        TextView messageText, timeText;

        ReceivedMessageHolder(View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.text_message_body);
            timeText = itemView.findViewById(R.id.text_message_time);
        }

        void bind(Message message) {
            messageText.setText(message.getContent());
            timeText.setText(formatDateTime(message.getTimestamp()));
        }
    }

    private String formatDateTime(Timestamp timestamp) {
        Date date = timestamp.toDate();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        return sdf.format(date);
    }
    class SentAudioHolder extends RecyclerView.ViewHolder {
        ImageButton playButton;
        TextView timeText;

        SentAudioHolder(View itemView) {
            super(itemView);
            playButton = itemView.findViewById(R.id.play_button);
            timeText = itemView.findViewById(R.id.text_message_time);
        }

        void bind(Message message) {
            timeText.setText(formatDateTime(message.getTimestamp()));
            playButton.setOnClickListener(v -> toggleAudioPlayback(message.getAudioUrl(), playButton));
        }
    }

    class ReceivedAudioHolder extends RecyclerView.ViewHolder {
        ImageButton playButton;
        TextView timeText;

        ReceivedAudioHolder(View itemView) {
            super(itemView);
            playButton = itemView.findViewById(R.id.play_button);
            timeText = itemView.findViewById(R.id.text_message_time);
        }

        void bind(Message message) {
            timeText.setText(formatDateTime(message.getTimestamp()));
            playButton.setOnClickListener(v -> toggleAudioPlayback(message.getAudioUrl(), playButton));
        }
    }

    private void toggleAudioPlayback(String audioUrl, ImageButton playButton) {
        if (currentMediaPlayer != null && currentMediaPlayer.isPlaying()) {
            if (currentPlayButton == playButton) {
                // Pause the current playback
                currentMediaPlayer.pause();
                playButton.setImageResource(R.drawable.ic_play); // Assuming you have a play icon
            } else {
                // Stop the current playback and start the new one
                stopCurrentPlayback();
                playAudio(audioUrl, playButton);
            }
        } else {
            // Start new playback
            playAudio(audioUrl, playButton);
        }
    }

    private void playAudio(String audioUrl, ImageButton playButton) {
        stopCurrentPlayback();

        currentMediaPlayer = new MediaPlayer();
        currentPlayButton = playButton;

        try {
            currentMediaPlayer.setDataSource(audioUrl);
            currentMediaPlayer.prepare();
            currentMediaPlayer.start();
            playButton.setImageResource(R.drawable.ic_pause); // Assuming you have a pause icon

            currentMediaPlayer.setOnCompletionListener(mp -> {
                playButton.setImageResource(R.drawable.ic_play);
                currentMediaPlayer = null;
                currentPlayButton = null;
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void stopCurrentPlayback() {
        if (currentMediaPlayer != null) {
            currentMediaPlayer.stop();
            currentMediaPlayer.release();
            currentMediaPlayer = null;
        }
        if (currentPlayButton != null) {
            currentPlayButton.setImageResource(R.drawable.ic_play);
            currentPlayButton = null;
        }
    }

}