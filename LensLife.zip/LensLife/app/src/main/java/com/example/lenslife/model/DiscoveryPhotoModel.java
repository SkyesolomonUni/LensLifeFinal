package com.example.lenslife.model;

import java.util.Date;
import java.util.Objects;

public class DiscoveryPhotoModel {
    private String postId;
    private String userId;
    private String imageUrl;
    private String caption;
    private Date timestamp;
    private String userName;
    private String userProfilePicUrl;
    private boolean isFollowing;
    private boolean userInfoLoaded = false;

    public DiscoveryPhotoModel() {}

    public DiscoveryPhotoModel(String postId, String userId, String imageUrl, String caption, Date timestamp, String userName, String userProfilePicUrl, boolean isFollowing) {
        this.postId = postId;
        this.userId = userId;
        this.imageUrl = imageUrl;
        this.caption = caption;
        this.timestamp = timestamp;
        this.userName = userName;
        this.userProfilePicUrl = userProfilePicUrl;
        this.isFollowing = isFollowing;
    }
    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserProfilePicUrl() {
        return userProfilePicUrl;
    }

    public void setUserProfilePicUrl(String userProfilePicUrl) {
        this.userProfilePicUrl = userProfilePicUrl;
    }
    public boolean isFollowing() {
        return isFollowing;
    }

    public void setFollowing(boolean following) {
        isFollowing = following;
    }
    public boolean isUserInfoLoaded() {
        return userInfoLoaded;
    }

    public void setUserInfoLoaded(boolean userInfoLoaded) {
        this.userInfoLoaded = userInfoLoaded;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DiscoveryPhotoModel that = (DiscoveryPhotoModel) o;
        return isFollowing == that.isFollowing &&
                Objects.equals(postId, that.postId) &&
                Objects.equals(userId, that.userId) &&
                Objects.equals(imageUrl, that.imageUrl) &&
                Objects.equals(caption, that.caption) &&
                Objects.equals(timestamp, that.timestamp) &&
                Objects.equals(userName, that.userName) &&
                Objects.equals(userProfilePicUrl, that.userProfilePicUrl);
    }

    @Override
    public int hashCode() {
        return Objects.hash(postId, userId, imageUrl, caption, timestamp, userName, userProfilePicUrl, isFollowing);
    }
}