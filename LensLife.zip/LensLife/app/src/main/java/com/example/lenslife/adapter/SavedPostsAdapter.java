package com.example.lenslife.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.lenslife.R;
import com.example.lenslife.model.SavedPost;

import java.util.List;

public class SavedPostsAdapter extends RecyclerView.Adapter<SavedPostsAdapter.SavedPostViewHolder> {
    private Context context;
    private List<SavedPost> savedPosts;

    public SavedPostsAdapter(Context context, List<SavedPost> savedPosts) {
        this.context = context;
        this.savedPosts = savedPosts;
    }

    @NonNull
    @Override
    public SavedPostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_saved_post, parent, false);
        return new SavedPostViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SavedPostViewHolder holder, int position) {
        SavedPost post = savedPosts.get(position);
        Glide.with(context).load(post.getImageUrl()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return savedPosts.size();
    }

    static class SavedPostViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        SavedPostViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.savedPostImage);
        }
    }
}