package com.example.lenslife.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.lenslife.R;
import com.example.lenslife.adapter.DiscoveryAdapter;
import com.example.lenslife.model.DiscoveryPhotoModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.HashSet;
import java.util.ArrayList;
import java.util.List;

public class DiscoveryFragment extends Fragment {

    private static final String TAG = "DiscoveryFragment";
    private EditText searchEditText;
    private RecyclerView photosRecyclerView;
    private DiscoveryAdapter discoveryAdapter;
    private List<DiscoveryPhotoModel> photoList;
    private HashSet<String> photoIds;

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_discovery, container, false);

        searchEditText = view.findViewById(R.id.searchEditText);
        photosRecyclerView = view.findViewById(R.id.photosRecyclerView);
        photosRecyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        photoList = new ArrayList<>();
        photoIds = new HashSet<>();
        discoveryAdapter = new DiscoveryAdapter(getContext(), photoList, this::handleFollowClick);
        photosRecyclerView.setAdapter(discoveryAdapter);

        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                searchPhotos(s.toString());
            }
        });

        loadRandomPosts();
        return view;
    }
    private void showToast(String message) {
        if (getContext() != null && isAdded()) {
            Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
        }
    }
    private void searchPhotos(String keyword) {
        if (keyword.isEmpty()) {
            loadRandomPosts();
            return;
        }

        String currentUserId = mAuth.getCurrentUser().getUid();
        db.collection("posts")
                .orderBy("caption")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<DiscoveryPhotoModel> tempList = new ArrayList<>();
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        DiscoveryPhotoModel photo = document.toObject(DiscoveryPhotoModel.class);
                        if (photo != null && !photo.getUserId().equals(currentUserId)) {
                            String caption = photo.getCaption().toLowerCase();
                            if (caption.contains(keyword.toLowerCase())) {
                                tempList.add(photo);
                                Log.d(TAG, "Matched post: " + photo.getPostId() + ", Caption: " + photo.getCaption());
                            }
                        }
                    }
                    updatePhotoList(tempList);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error searching photos", e);
                    showToast("Error searching photos");
                });
    }

    private void loadRandomPosts() {
        String currentUserId = mAuth.getCurrentUser().getUid();
        db.collection("posts")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(20)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<DiscoveryPhotoModel> tempList = new ArrayList<>();
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        DiscoveryPhotoModel photo = document.toObject(DiscoveryPhotoModel.class);
                        if (photo != null && !photo.getUserId().equals(currentUserId)) {
                            tempList.add(photo);
                            Log.d(TAG, "Loaded random post: " + photo.getPostId() + ", Caption: " + photo.getCaption());
                        }
                    }
                    updatePhotoList(tempList);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error loading random posts", e);
                    showToast("Error loading posts");
                });
    }

    private void updatePhotoList(List<DiscoveryPhotoModel> newList) {
        photoList.clear();
        photoList.addAll(newList);
        discoveryAdapter.notifyDataSetChanged();

        if (photoList.isEmpty()) {
            showToast("No results found");
        } else {
            for (DiscoveryPhotoModel photo : photoList) {
                loadUserInfo(photo);
            }
        }
    }

    private void loadUserInfo(DiscoveryPhotoModel photo) {
        db.collection("users").document(photo.getUserId())
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        photo.setUserName(documentSnapshot.getString("name"));
                        photo.setUserProfilePicUrl(documentSnapshot.getString("profilePicUrl"));
                        checkIfFollowing(photo);
                    } else {
                        Log.d(TAG, "User document does not exist for: " + photo.getUserId());
                    }
                })
                .addOnFailureListener(e -> Log.e(TAG, "Error loading user info for: " + photo.getUserId(), e));
    }

    private void checkIfFollowing(DiscoveryPhotoModel photo) {
        String currentUserId = mAuth.getCurrentUser().getUid();
        db.collection("users").document(currentUserId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        List<String> following = (List<String>) documentSnapshot.get("following");
                        if (following != null && following.contains(photo.getUserId())) {
                            photo.setFollowing(true);
                        } else {
                            photo.setFollowing(false);
                        }
                        int position = photoList.indexOf(photo);
                        if (position != -1) {
                            discoveryAdapter.notifyItemChanged(position);
                        }
                    }
                })
                .addOnFailureListener(e -> Log.e(TAG, "Error checking if following", e));
    }

    private void handleFollowClick(String userId, int position, boolean follow) {
        String currentUserId = mAuth.getCurrentUser().getUid();
        if (currentUserId.equals(userId)) {
            return; // Can't follow yourself
        }

        if (follow) {
            // Follow the user
            db.collection("users").document(currentUserId)
                    .update("following", FieldValue.arrayUnion(userId))
                    .addOnSuccessListener(aVoid -> {
                        db.collection("users").document(userId)
                                .update("followers", FieldValue.arrayUnion(currentUserId))
                                .addOnSuccessListener(aVoid1 -> {
                                    photoList.get(position).setFollowing(true);
                                    discoveryAdapter.notifyItemChanged(position);
                                    showToast("Followed successfully");
                                })
                                .addOnFailureListener(e -> Log.e(TAG, "Error updating followers", e));
                    })
                    .addOnFailureListener(e -> Log.e(TAG, "Error updating following", e));
        } else {
            // Unfollow the user
            db.collection("users").document(currentUserId)
                    .update("following", FieldValue.arrayRemove(userId))
                    .addOnSuccessListener(aVoid -> {
                        db.collection("users").document(userId)
                                .update("followers", FieldValue.arrayRemove(currentUserId))
                                .addOnSuccessListener(aVoid1 -> {
                                    photoList.get(position).setFollowing(false);
                                    discoveryAdapter.notifyItemChanged(position);
                                    showToast("Unfollowed successfully");
                                })
                                .addOnFailureListener(e -> Log.e(TAG, "Error updating followers", e));
                    })
                    .addOnFailureListener(e -> Log.e(TAG, "Error updating following", e));
        }
    }
}
