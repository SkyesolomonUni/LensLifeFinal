package com.example.lenslife.model;

import com.google.firebase.Timestamp;

import java.util.List;

import com.google.firebase.Timestamp;

public class HomePostModel {
    private String postId;
    private String userId;
    private String caption;
    private String imageUrl;
    private Timestamp timestamp;
    private int likesCount;
    private boolean likedByCurrentUser;

    public HomePostModel() {}

    public HomePostModel(String postId, String userId, String caption, String imageUrl, Timestamp timestamp, int likesCount) {
        this.postId = postId;
        this.userId = userId;
        this.caption = caption;
        this.imageUrl = imageUrl;
        this.timestamp = timestamp;
        this.likesCount = likesCount;
    }

    public String getPostId() {
        return postId;
    }
    public boolean isLikedByCurrentUser() {
        return likedByCurrentUser;
    }

    public void setLikedByCurrentUser(boolean likedByCurrentUser) {
        this.likedByCurrentUser = likedByCurrentUser;
    }
    public int getLikesCount() {
        return likesCount;
    }

    public void setLikesCount(int likesCount) {
        this.likesCount = likesCount;
    }
    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
}