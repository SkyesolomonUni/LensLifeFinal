package com.example.lenslife.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.example.lenslife.R;
import com.example.lenslife.model.AddPost;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.util.List;

public class ProfileAdapter extends BaseAdapter {

    private Context context;
    private List<AddPost> posts;
    private String userId;
    private StorageReference storageRef;

    public ProfileAdapter(Context context, List<AddPost> posts, String userId) {
        this.context = context;
        this.posts = posts;
        this.userId = userId;
        this.storageRef = FirebaseStorage.getInstance().getReference();
    }

    @Override
    public int getCount() {
        return posts.size() + 1; // +1 for the profile picture
    }

    @Override
    public Object getItem(int position) {
        if (position == 0) {
            return "profile";
        }
        return posts.get(position - 1);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if (convertView == null) {
            imageView = new ImageView(context);
            imageView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 300));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            imageView = (ImageView) convertView;
        }

        if (position == 0) {
            // Load profile picture
            StorageReference profilePicRef = storageRef.child("profile_pics/" + userId + ".jpg");
            profilePicRef.getDownloadUrl().addOnSuccessListener(uri -> {
                Glide.with(context)
                        .load(uri)
                        .circleCrop()
                        .into(imageView);
            }).addOnFailureListener(e -> {
                // Load a default image if profile picture is not available
                Glide.with(context)
                        .load(R.drawable.ic_profile)
                        .circleCrop()
                        .into(imageView);
            });
        } else {
            // Load post image
            AddPost post = posts.get(position - 1);
            Glide.with(context)
                    .load(post.getImageUrl())
                    .into(imageView);
        }

        return imageView;
    }
}