package com.example.lenslife.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lenslife.R;
import com.example.lenslife.adapter.SavedPostsAdapter;
import com.example.lenslife.model.SavedPost;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class SavedPostsFragment extends Fragment {
    private RecyclerView recyclerView;
    private SavedPostsAdapter adapter;
    private List<SavedPost> savedPosts;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_saved_posts, container, false);

        recyclerView = view.findViewById(R.id.savedPostsRecyclerView);
        savedPosts = new ArrayList<>();
        adapter = new SavedPostsAdapter(getContext(), savedPosts);

        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        recyclerView.setAdapter(adapter);

        loadSavedPosts();

        return view;
    }

    private void loadSavedPosts() {
        String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseFirestore.getInstance().collection("users").document(currentUserId)
                .collection("savedPosts").get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    savedPosts.clear();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        SavedPost post = document.toObject(SavedPost.class);
                        savedPosts.add(post);
                    }
                    adapter.notifyDataSetChanged();
                });
    }
}