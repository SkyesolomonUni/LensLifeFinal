package com.example.lenslife;

import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.lenslife.ui.AddPostFragment;
import com.example.lenslife.ui.DiscoveryFragment;
import com.example.lenslife.ui.HomeFragment;
import com.example.lenslife.ui.MessagingFragment;
import com.example.lenslife.ui.ProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class BaseActivity extends AppCompatActivity {

    protected BottomNavigationView bottomNavigationView;
    private static final long FRAGMENT_SWITCH_DELAY = 50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // The layout should be set in the subclass
    }

    protected void setupBottomNavigation(Bundle savedInstanceState) {
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            Fragment selectedFragment;
            int itemId = item.getItemId();

            if (itemId == R.id.navigation_home) {
                selectedFragment = new HomeFragment();
            } else if (itemId == R.id.navigation_search) {
                selectedFragment = new DiscoveryFragment();
            } else if (itemId == R.id.navigation_add) {
                selectedFragment = new AddPostFragment();
            } else if (itemId == R.id.chat_profile) {
                selectedFragment = new MessagingFragment();

            } else if (itemId == R.id.navigation_profile) {
                selectedFragment = new ProfileFragment();
            } else {
                selectedFragment = null;
            }

            if (selectedFragment != null) {
                new Handler().postDelayed(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment_container, selectedFragment)
                                .commit();
                    }
                }, FRAGMENT_SWITCH_DELAY);
            }

            return true;
        });

        // Set default fragment
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new HomeFragment())
                    .commit();
        }
    }
}
